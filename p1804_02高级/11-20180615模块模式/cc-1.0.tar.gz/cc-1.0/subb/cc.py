def cc():
    print ('c')
