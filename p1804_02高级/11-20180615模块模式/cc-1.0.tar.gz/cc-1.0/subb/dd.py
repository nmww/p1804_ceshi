def dd():
    print ('d')
