def aa():
    print ('a')
