def bb():
    print ('b')
