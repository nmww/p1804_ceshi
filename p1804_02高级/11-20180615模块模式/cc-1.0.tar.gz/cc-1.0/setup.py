from distutils.core import setup

setup(name="cc", version="1.0", description="this is test mod", author="cc", py_modules=['suba.aa', 'suba.bb', 'subb.cc', 'subb.dd'])
