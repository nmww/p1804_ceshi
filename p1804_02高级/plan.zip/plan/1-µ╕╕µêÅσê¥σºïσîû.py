import pygame

pygame.init()
"""
"""

pygame.quit()

