import pygame

pygame.init()

pygame.display.set_mode((480,700))

while True:
	pass

pygame.quit()
